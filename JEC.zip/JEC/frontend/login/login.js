// Usuário e senha de exemplo
const usuarioCorreto = 'admin@jec.com';
const senhaCorreta = '123456';

const form = document.getElementById('loginForm');
const errorMessage = document.getElementById('error-message');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;

  if (email === usuarioCorreto && senha === senhaCorreta) {
    errorMessage.style.display = 'none';
    alert('Login realizado com sucesso!');
    // window.location.href = 'pagina-inicial.html';
  } else {
    errorMessage.textContent = 'E-mail ou senha incorretos.';
    errorMessage.style.display = 'block';
  }
});

form.addEventListener('input', function() {
  errorMessage.style.display = 'none';
}); 